package com.project.appoinmentservice.model;

public enum AppointmentStatus {
    PENDING,
    CONFIRMED,
    FAILED
}
