package com.project.appoinmentservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppoinmentserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
