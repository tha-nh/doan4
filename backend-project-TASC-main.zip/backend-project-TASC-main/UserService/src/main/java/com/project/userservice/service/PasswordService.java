package com.project.userservice.service;

public interface PasswordService {
    public String generateRandomPassword();
}
