package com.project.paymentservice.model;

public enum PaymentStatus {
    PENDING,
    COMPLETED,
    FAILED
}
