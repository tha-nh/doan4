import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import {
  NavigationEnd,
  Router,
  RouterLink,
  RouterOutlet,
} from '@angular/router';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { NzMenuModule } from 'ng-zorro-antd/menu';
import { ROUTE_MAP, RouteItem } from './route-config';
import { AuthService } from './services/auth.service';

@Component({
  selector: 'app-root',
  imports: [
    RouterLink,
    RouterOutlet,
    NzIconModule,
    NzLayoutModule,
    NzMenuModule,
    CommonModule,
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
})
export class AppComponent {
  isCollapsed = false;
  showLayout = false;
  filteredRoutes: RouteItem[] = [];

  constructor(private router: Router, private authService: AuthService) {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.showLayout =
          !event.url.includes('/login') && !event.url.includes('/not-found');
      }
    });
  }

  ngOnInit() {
    const userRole = this.authService.getCurrentUserRole();
    this.filteredRoutes = this.filterRoutesByRole(ROUTE_MAP, userRole);
  }

  filterRoutesByRole(routes: RouteItem[], role: string): RouteItem[] {
    return routes
      .filter((route) => route.roles.includes(role))
      .map((route) => ({
        ...route,
        children: route.children
          ? route.children.filter((child) => child.roles.includes(role))
          : [],
      }));
  }

  logout() {
    this.authService.logout();
  }
}
