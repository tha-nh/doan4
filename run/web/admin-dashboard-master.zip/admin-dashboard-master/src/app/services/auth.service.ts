import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  constructor(private http: HttpClient) {}

  login(data: any) {
    return this.http.post('http://localhost:8080/api/v1/staffs/login', data);
  }

  getCurrentUserRole(): string {
    return localStorage.getItem('role') || '';
  }

  logout() {
    localStorage.clear();
    window.location.href = '/login';
  }
}
