export interface RouteItem {
  title: string;
  path?: string;
  icon?: string;
  children?: RouteItem[];
  roles: string[];
}

export const ROUTE_MAP: RouteItem[] = [
  {
    title: 'Dashboard',
    icon: 'dashboard',
    roles: ['admin', 'doctor', 'patient'],
    children: [
      {
        title: 'Home',
        path: '/dashboard/home',
        roles: ['admin', 'doctor', 'patient'],
      },
      {
        title: 'Departments & Doctors',
        path: '/dashboard/departments',
        roles: ['admin', 'doctor'],
      },
      {
        title: 'Patients',
        path: '/dashboard/patients',
        roles: ['admin'],
      },
      {
        title: 'Appointments',
        path: '/dashboard/appointments',
        roles: ['admin', 'doctor', 'patient'],
      },
      {
        title: 'Staffs',
        path: '/dashboard/staffs',
        roles: ['admin'],
      },
    ],
  },
  {
    title: 'Settings',
    icon: 'setting',
    roles: ['admin', 'doctor', 'patient'],
    children: [
      {
        title: 'Profile',
        path: '/profile',
        roles: ['admin', 'doctor', 'patient'],
      },
      {
        title: 'Logout',
        path: '#',
        roles: ['admin', 'doctor', 'patient'],
      },
    ],
  },
];
