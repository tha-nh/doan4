import {
  MenuFoldOutline,
  MenuUnfoldOutline,
  FormOutline,
  DashboardOutline,
  SettingOutline,
  UserOutline,
  LockOutline,
  EyeOutline,
  EyeInvisibleOutline,
} from '@ant-design/icons-angular/icons';

export const icons = [
  MenuFoldOutline,
  MenuUnfoldOutline,
  DashboardOutline,
  FormOutline,
  SettingOutline,
  UserOutline,
  LockOutline,
  EyeOutline,
  EyeInvisibleOutline,
];
