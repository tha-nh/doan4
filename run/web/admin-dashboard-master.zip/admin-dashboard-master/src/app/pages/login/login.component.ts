import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzCheckboxModule } from 'ng-zorro-antd/checkbox';
import { NzFlexModule } from 'ng-zorro-antd/flex';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { NzInputModule } from 'ng-zorro-antd/input';
import { AuthService } from '../../services/auth.service';
import { NzAlertModule } from 'ng-zorro-antd/alert';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { NzIconModule } from 'ng-zorro-antd/icon';

@Component({
  selector: 'app-login',
  imports: [
    ReactiveFormsModule,
    NzButtonModule,
    NzCheckboxModule,
    NzFormModule,
    NzInputModule,
    CommonModule,
    NzIconModule,
    NzFlexModule,
    NzGridModule,
    NzAlertModule,
  ],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss',
})
export class LoginComponent {
  methodForm: FormGroup = new FormGroup({});
  loading: boolean = false;
  passwordVisible = false;

  constructor(
    private formBuilder: FormBuilder,
    private authService: AuthService,
    private notification: NzNotificationService
  ) {}

  ngOnInit(): void {
    this.methodForm = this.formBuilder.group({
      username: ['', [Validators.required]],
      password: ['', [Validators.required]],
    });
  }

  handleSubmit() {
    if (this.methodForm.invalid) {
      Object.values(this.methodForm.controls).forEach((control) => {
        if (control.invalid) {
          control.markAsDirty();
          control.updateValueAndValidity({ onlySelf: true });
        }
      });
      return;
    }
    this.loading = true;
    this.methodForm.disable();
    this.authService.login(this.methodForm.value).subscribe({
      next: (res: any) => {
        localStorage.setItem('id', res.staff_id);
        localStorage.setItem('role', res.staff_type);
        localStorage.setItem('name', res.staff_name);
        this.showNotification('success');
        setTimeout(() => {
          window.location.href = '/dashboard/home';
        }, 1000);
      },
      error: (err) => {
        this.loading = false;
        this.methodForm.enable();
        this.showNotification('error');
      },
    });
  }

  showNotification(type: string): void {
    this.notification.create(
      type,
      type === 'success' ? 'Successful' : 'Failed',
      type === 'success'
        ? 'Login successful! Redirecting...'
        : 'Login failed! Please check your credentials.',
      {
        nzDuration: 3000,
        nzPlacement: 'topRight',
        nzClass: type === 'success' ? 'custom-success' : 'custom-error',
      }
    );
  }
}
