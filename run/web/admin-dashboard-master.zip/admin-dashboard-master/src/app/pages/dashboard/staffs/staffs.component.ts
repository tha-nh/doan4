import { Component } from '@angular/core';

@Component({
  selector: 'app-staffs',
  imports: [],
  templateUrl: './staffs.component.html',
  styleUrl: './staffs.component.scss'
})
export class StaffsComponent {

}
