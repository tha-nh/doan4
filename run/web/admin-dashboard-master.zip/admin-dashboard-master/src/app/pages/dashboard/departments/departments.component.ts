import { Component } from '@angular/core';

@Component({
  selector: 'app-departments',
  imports: [],
  templateUrl: './departments.component.html',
  styleUrl: './departments.component.scss'
})
export class DepartmentsComponent {

}
