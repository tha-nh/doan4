namespace productservices.DTO
{
    public class TourScheduleUpdateDTO
    {
         public string Name { get; set; } // Tên gói tour
    public decimal PackagePrice { get; set; } // Giá gói tour
    public string Description { get; set; } // Mô tả lịch trình tour
    }
}
