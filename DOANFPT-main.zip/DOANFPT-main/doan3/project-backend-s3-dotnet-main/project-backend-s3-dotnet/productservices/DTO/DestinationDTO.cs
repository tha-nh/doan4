namespace productservices.DTO
{
    public class DestinationDTO
    {
        public string Name { get; set; } // Tên địa điểm
        public string Description { get; set; } // Mô tả
    }
}