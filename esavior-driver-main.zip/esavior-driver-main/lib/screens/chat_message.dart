class ChatMessage {
  final String message;
  ChatMessage({required this.message});
}